from boltons.statsutils import Stats, mode


def test_stats_basic():
    da = Stats(range(20))
    assert da.mean == 9.5
    assert round(da.std_dev, 2) == 5.77
    assert da.variance == 33.25
    assert da.skewness == 0
    assert round(da.kurtosis, 1) == 1.9
    assert da.median == 9.5


def test_pearson_type_covers_kappa_ge_zero():
    # pearson_type used to raise RuntimeError('missed a spot') whenever the
    # Pearson criterion (kappa) was >= 0, i.e. Types IV/V/VI, which ordinary
    # small samples routinely land in. It should classify them instead.
    assert Stats([8, 4, 4, 4, 5, 1, 6, 5]).pearson_type == 4  # Type IV
    for data in ([0, 1, 2, 3, 4], [1, 1, 2, 3, 5, 8, 13], range(9)):
        assert Stats(data).pearson_type in (0, 1, 2, 3, 4, 5, 6, 7)


def test_mode():
    assert Stats([2, 1, 3, 1]).mode == 1
    # ties resolve to the value seen first in the data
    assert mode([1, 1, 2, 2, 3]) == 1
    # non-numeric, categorical data is supported
    assert mode(['a', 'b', 'b', 'c', 'c', 'c']) == 'c'
    # empty data falls back to the configured default
    assert Stats([], default=None).mode is None


def _test_pearson():
    import random
    from statsutils import pearson_type

    def get_pt(dist):
        vals = [dist() for x in range(10000)]
        pt = pearson_type(vals)
        return pt

    for x in range(3):
        # pt = get_pt(dist=lambda: random.normalvariate(15, 5))  # expect 0, normal
        # pt = get_pt(dist=lambda: random.weibullvariate(2, 3))  # gets 1, beta, weibull not specifically supported
        # pt = get_pt(dist=lambda: random.gammavariate(2, 3))  # expect 3, gamma
        # pt = get_pt(dist=lambda: random.betavariate(2, 3))  # expect 1, beta
        # pt = get_pt(dist=lambda: random.expovariate(0.2))  # expect 3, beta
        pt = get_pt(dist=lambda: random.uniform(0.0, 10.0))  # gets 2
        print('pearson type:', pt)

        # import pdb;pdb.set_trace()


def test_histogram_zero_interquartile_range():
    for data in ([5] * 10, [0] * 10 + [100]):
        counts = Stats(data).get_histogram_counts()
        assert counts == [(float(min(data)), len(data))]
        assert Stats(data).format_histogram()
